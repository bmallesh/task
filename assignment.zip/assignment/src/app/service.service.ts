import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor() { }
  mobile(){
    return [{ img: "nokia.jpeg", name: "Nokia 5", price: 11000, rating: 1 },
    { img: "nokia1.jpeg", name: "Nokia 7 Plus", price: 25000, rating: 2 },
    { img: "nokia2.jpeg", name: "Nokia 8", price: 22000, rating: 3 },
    { img: "nokia3.jpeg", name: "Nokia 6.1", price: 18999, rating: 5 },
    { img: "smg.jpeg", name: "Samsung Galaxy", price: 5450, rating: 3 },
    { img: "smg1.jpeg", name: "Samsung On7 Pro", price: 6000, rating: 4.5 },
    { img: "smg2.jpeg", name: "Samsung Guru", price: 7400, rating: 3.5 },
    { img: "smg3.jpeg", name: "Samsung Galaxy ", price: 4450, rating: 4.5 },
    { img: "vivo.jpeg", name: "Vivo V9", price: 20520, rating: 4.5 },
    { img: "vivo1.jpeg", name: "Vivo Y53i 1606", price: 70200, rating: 3.5 },
    { img: "vivo2.jpeg", name: "Vivo Y71", price: 10990, rating: 4.5 },
    { img: "vivo3.jpeg", name: "Vivo Y83", price: 14990, rating: 4.5 },
    { img: "redmi.jpeg", name: "Redmi 5", price: 8999, rating: 4.5 },
    { img: "redmi1.jpeg", name: "Redmi Y2", price: 14990, rating: 4.5 },
    { img: "redmi2.jpeg", name: "Redmi Note 4", price: 14000, rating: 4.5 },
    { img: "vivo3.jpeg", name: "Vivo Y83", price: 14990, rating: 10 }];
  }
  //------------------laptops--------------------------
  laptop(){
    return [{img:"hp.jpeg",name:"HP 15q Core i3",price:29000,rating:4.5},
    {img:"hp.jpeg",name:"HP 15q Core i3",price:29000,rating:4.5},
    {img:"hp1.jpeg",name:"HP 15q Core i3",price:28000,rating:5},
    {img:"lenovo.jpeg",name:"Lenovo Core i5",price:30000,rating:3.5},
    {img:"lenovo1.jpeg",name:"Lenovo Ideapad ",price:39000,rating:4.5},
    {img:"acer.jpeg",name:"Acer",price:29999,rating:4.5},
    {img:"asus.jpeg",name:"Asus",price:17000,rating:5},
    {img:"dell.jpeg",name:"Dell Inspiron",price:24000,rating:3},
    {img:"msi.jpeg",name:"MSI GL Series",price:29000,rating:4.5},
    {img:"apple.jpeg",name:"Apple MacBook",price:69000,rating:5},
    {img:"hp.jpeg",name:"HP 15q Core i3",price:29000,rating:4.5}];
  }
  //------------------television--------------------------
  television(){
    return [{img:"tv8.jpeg",name:"Micromax 106cm ",price:21999,rating:3},
    {img:"tv8.jpeg",name:"Micromax 106cm ",price:21999,rating:3},
    {img:"tv7.jpeg",name:" LIVEGENIUS",price:26900,rating:4.5},
    {img:"tv6.jpeg",name:"Vu Premium ",price:26400,rating:3},
    {img:"tv5.jpeg",name:"Noble Skiodo",price:6999,rating:4.5},
    {img:"tv4.jpeg",name:"Vu Pixelight",price:36999,rating:5},
    {img:"tv3.jpeg",name:"Kodak 80cm ",price:21999,rating:3},
    {img:"tv8.jpeg",name:"Micromax 106cm ",price:21999,rating:3.5},
    {img:"tv2.jpeg",name:"Kodak 80cm ",price:22999,rating:4.5},
    {img:"tv8.jpeg",name:"Micromax ",price:21099,rating:3.5},
    {img:"tv1.jpeg",name:"Noble Skiodo",price:21999,rating:5}];
  }
  //------------------refrigerator--------------------
  refrigerator(){
    return [{img:"ref.jpeg",name:"Godrej 185",price:14999,rating:4.5},
    {img:"ref.jpeg",name:"Godrej 185",price:14999,rating:4.5},
    {img:"ref.jpeg",name:"Godrej 185",price:14999,rating:4.5},
    {img:"ref2.jpeg",name:"Haier 52",price:6999,rating:5},
    {img:"ref3.jpeg",name:"Samsung 192",price:8999,rating:3.5},
    {img:"ref4.jpeg",name:"LG 190 L Direct",price:14000,rating:4.5},
    {img:"ref5.jpeg",name:"Haier 565 L",price:14999,rating:3.5},
    {img:"ref6.jpeg",name:"Haier 181",price:13099,rating:4},
    {img:"ref7.jpeg",name:"LG 190 L Direc",price:13099,rating:4.5},
    {img:"ref8.jpeg",name:"LG 260 L",price:24999,rating:5},
    {img:"ref4.jpeg",name:"Samsung 185",price:14999,rating:4.5},
    {img:"ref2.jpeg",name:"GodHaier",price:20000,rating:3.5},
    {img:"ref.jpeg",name:"Godrej Haier",price:14999,rating:4.5},
    {img:"ref5.jpeg",name:"Godrej 185",price:14999,rating:4}];
  }
  //-------------------airconditioner---------------
  airconditioner(){
    var airconditioner=[{img:"ac.jpeg",name:"LumX 1.5 Ton ",price:21999,rating:4},
    {img:"ac5.jpeg",name:"Godrej 185",price:14900,rating:4.5},
    {img:"ac2.jpeg",name:"MarQ by",price:10999,rating:3},
    {img:"ac3.jpeg",name:"GodMarQ by",price:13999,rating:4},
    {img:"ac4.jpeg",name:"Panasonic",price:14999,rating:4.5},
    {img:"ac5.jpeg",name:"DedPanasonic",price:29559,rating:5},
    {img:"ac6.jpeg",name:"Carrier 1.5",price:10034,rating:4},
    {img:"ac5.jpeg",name:"Sansui 1.5",price:12909,rating:3.5},
    {img:"ac3.jpeg",name:"Midea 1 Ton ",price:10399,rating:4},
    {img:"ac5.jpeg",name:"Godrej 185",price:14009,rating:4.5},
    {img:"ac4.jpeg",name:"Hitachi 1 Ton",price:10339,rating:5},]
    return airconditioner;
  }

}
