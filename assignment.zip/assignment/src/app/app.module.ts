import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FilterPipeModule } from 'ngx-filter-pipe';
import { FormsModule } from "@angular/forms";
import { Ng2SearchPipeModule } from 'ng2-search-filter';


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { DetailsComponent } from './details/details.component';
import { ServiceService } from './service.service';


var ob = [{ path: "", component: HomeComponent },
{ path: "product", component: ProductComponent },
{ path: "details", component: DetailsComponent }]

var rout = RouterModule.forRoot(ob)

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ProductComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule, RouterModule, rout, FilterPipeModule, FormsModule, Ng2SearchPipeModule
  ],
  providers: [ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
