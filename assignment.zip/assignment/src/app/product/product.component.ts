import { Component, OnInit, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceService } from '../service.service';



@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  mobiles;airconditioners;refrigerators;televisions;laptops
  constructor(@Inject(ActivatedRoute) public ar,service:ServiceService) {
    this.mobiles=service.mobile();
    this.laptops=service.laptop();
    this.televisions=service.television();
    this.refrigerators=service.refrigerator();
    this.airconditioners=service.airconditioner();
   }

   filterbyname:any={name:""}
   filterprice:any={price:""}
   filterrating:any={rating:""}

  ngOnInit() {
    this.product();
  }

  pid;
  product() {
    this.ar.params.subscribe(dt => {
      this.pid = dt.id;
      //alert(this.productdata.id)
      //console.log(dt.id)
    })
  }
  flag = true; rat = []; half = false;
  fun1(rating) {
    //alert(rating)
    this.half = false;
    this.rat = []
    for (var i = 1; i <= rating; i++) {
      //alert("hi")
      this.rat.push(i)
      //alert(this.rat)
    }
    i--;
    //alert(this.pdata.rating)
    if (i < rating) {
      this.half = true;
    }
    this.flag = false;
  }

}
