import { Component, OnInit,Inject } from '@angular/core';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  constructor(@Inject (ActivatedRoute) public ar) { }
  pdata;
  ngOnInit() {
    this.ar.params.subscribe(dt=>{
      this.pdata=dt;
    })
    this.rating();
  }
  rat=[];half=false;
  rating(){
    for(var i=1;i<=this.pdata.rating;i++){
      //alert("hi")
      this.rat.push(i)
      //alert(this.rat)
    }
    i--;
    //alert(this.pdata.rating)
    if(i<this.pdata.rating){
      this.half=true;
    }
  }

}
